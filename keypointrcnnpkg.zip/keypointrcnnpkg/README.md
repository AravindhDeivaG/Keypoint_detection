# Run Keypoint Rcnn in real time

* Activate conda environment "my-torch"
```
conda activate my-torch
```

* Run (keypointrcnn.py)[https://gitlab.com/barczyk-mechatronic-systems-lab/keypoint_detection/-/blob/main/keypointrcnnpkg/scripts/keypointrcnn.py] script inside the conda environment.

# Output 

![](keypoint_rcnn_output_1.gif)
